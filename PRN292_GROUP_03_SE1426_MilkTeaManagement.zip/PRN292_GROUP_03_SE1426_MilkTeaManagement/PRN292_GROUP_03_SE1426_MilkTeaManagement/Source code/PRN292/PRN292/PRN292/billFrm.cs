﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRN292.BUS;
using PRN292.DB;
using PRN292.DTO;
namespace PRN292
{
    public partial class billFrm : Form
    {
        MilkTeaBUS bus = new MilkTeaBUS();
        BillBUS billBUS = new BillBUS();
        BillInfoBUS billInfoBUS = new BillInfoBUS();

        //MilkTea.DbConnection db = new MilkTea.DbConnection();
        List<Category> listCategory;
        List<MilkTea> list;
        DataTable data = new DataTable();
        int index;
        string tenmonan;
        SqlConnection conn;
        public billFrm()
        {
            InitializeComponent();
            loadListTea();
        }
        void loadListTea()
        {
            list = bus.GetListMilkTea();
            foreach (MilkTea dto in list)
            {
                cboFood.Items.Add(dto.MilkTeaName);
            }
            cboFood.SelectedIndex = 1;
        }



        private void btnAddFood_Click(object sender, EventArgs e)
        {
            try
            {

            
            if (string.IsNullOrEmpty(cboFood.SelectedItem.ToString()))
            {
                MessageBox.Show("Please Add Food first.", "Message");
                return;
            }
            if (string.IsNullOrEmpty(txtID.Text))
            {
                MessageBox.Show("Please Add Food first.", "Message");
                return;
            }
            if (string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Please Add Food first.", "Message");
                return;
            }
            string name = cboFood.SelectedItem.ToString();
            string ID = txtID.Text;
            double price = double.Parse(txtPrice.Text);
            double qty = double.Parse(txtQuantity.Text);
            double tot = price * qty;


            int sum = 0;
            for (int row = 0; row < dgvListFood.Rows.Count; row++)
            {
                if (dgvListFood.Rows[row].Cells[0].Value.ToString().Equals(ID))
                {
                    MessageBox.Show("This food already added. Please delete and change the quantity.", "Message");
                    return;
                }
            }
            this.dgvListFood.Rows.Add(ID, name, qty, price, tot);
            for (int row = 0; row < dgvListFood.Rows.Count; row++)
            {
                sum = sum + Convert.ToInt32(dgvListFood.Rows[row].Cells[4].Value);
            }
            // cboMonAn.
            txtTotal.Text = sum.ToString();
            //txtID.Clear();
            //txtdname.Clear();
            //txtPrice.Clear();
            txtQuantity.Text = "1";
            }catch(Exception ex)
            {
                MessageBox.Show("Please add food first.", "Message");
            }
        }

        private void hoaDonFrm_Load(object sender, EventArgs e)
        {

        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtPayment.Text))
            {
                MessageBox.Show("Please enter payment.", "Message");
                return;
            }
            if (string.IsNullOrEmpty(txtID.Text))
            {
                MessageBox.Show("Please choose food and add food to list.", "Message");
                return;
            }
            if (string.IsNullOrEmpty(txtPrice.Text))
            {
                MessageBox.Show("Please choose food and add food to list.", "Message");
                return;
            }
            if (string.IsNullOrEmpty(txtTotal.Text))
            {
                MessageBox.Show("Please choose food and add food to list.", "Message");
                return;
            }


            double total = double.Parse(txtTotal.Text);//21
            double discount = total * (double.Parse(nbDiscount.Text) / 100);//0
            double subtotal = total - discount;

            double pay = double.Parse(txtPayment.Text);
            if(pay < total)
            {
                MessageBox.Show("Please pay more money.", "Message");
                return;
            }
            double bal = pay - subtotal;
            txtBalance.Text = bal.ToString();
            SaveHD();
        }
        public void SaveHD()
        {
            if (dgvListFood.Rows.Count == 0)
            {
                MessageBox.Show("Please add new food.", "Message");
                return;
            }
            string total = txtTotal.Text;
            string pay = txtPayment.Text;
            string discount = nbDiscount.Value.ToString();
            string bal = txtBalance.Text;
            DateTime time = DateTime.Now;
            Bill dtoo = new Bill
            {
                TimeOfCreate = time,
                SumOfMoney = Double.Parse(total),
                Discount = int.Parse(discount),
                Pay = double.Parse(pay),
                Balance = double.Parse(bal)
            };
            int lastid = billBUS.InsertBill(dtoo);
            string MilkteaID;
            int price = 0;
            int qty = 0;
            int tot = 0;
            bool check = false;

            for (int row = 0; row < dgvListFood.Rows.Count; row++)
            {
                MilkteaID = dgvListFood.Rows[row].Cells[0].Value.ToString();
                //string MilkTeaID =dgvListMonAn.Rows[row].Cells[0].Value.ToString();
                qty = int.Parse(dgvListFood.Rows[row].Cells[2].Value.ToString());
                price = int.Parse(dgvListFood.Rows[row].Cells[3].Value.ToString());
                tot = int.Parse(dgvListFood.Rows[row].Cells[4].Value.ToString());

                BillInfo dtoBillInfo = new BillInfo
                {
                    BillID = lastid,
                    MilkTeaID = MilkteaID,
                    Quantity = qty,
                    Price = price,
                    Money = tot
                };
                check = billInfoBUS.InsertBillInfo(dtoBillInfo);
                check = true;
            }
            if (check)
            {
                MessageBox.Show("Create Bill Successful.", "Message");
                dgvListFood.Rows.Clear();
                txtPayment.Text = "";
                txtBalance.Text = "";
            }
            printFrm print = new printFrm(lastid);
            print.Show();


        }

        private void dgvListMonAn_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListFood.Columns["Delete"].Index && e.RowIndex >= 0)
            {
                

                int sum = 0;
                for (int row = 0; row < dgvListFood.Rows.Count; row++)
                {
                    sum = sum + Convert.ToInt32(dgvListFood.Rows[row].Cells[4].Value);
                }

                txtTotal.Text = sum.ToString();
            }
        }

        private void cboMonAn_SelectedIndexChanged(object sender, EventArgs e)
        {
            string monan = cboFood.SelectedItem.ToString();
            MilkTea dto = billBUS.getMilkTeaInfo(monan);
            txtID.Text = dto.MilkTeaID;
            txtPrice.Text = dto.Price.ToString();
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
