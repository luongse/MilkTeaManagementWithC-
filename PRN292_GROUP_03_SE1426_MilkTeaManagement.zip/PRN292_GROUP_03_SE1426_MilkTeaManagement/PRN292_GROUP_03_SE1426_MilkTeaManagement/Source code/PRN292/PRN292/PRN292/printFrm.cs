﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRN292.BUS;
using PRN292.DTO;

namespace PRN292
{
    public partial class printFrm : Form
    {
        DataTable dtBill;
        DataTable dtBillInfo;
        BillBUS BillBus = new BillBUS();
        BillInfoBUS billInfoBus = new BillInfoBUS();

        public printFrm(int BillID)
        {
            InitializeComponent();
            loadTable(BillID);
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
        public void loadTable(int BillID)
        {
            dtBill = BillBus.getBill(BillID);
            dtBillInfo = billInfoBus.getBillInfo(BillID);
            BillReportPrint cr = new BillReportPrint();
            cr.Database.Tables["Bill"].SetDataSource(dtBill);
            cr.Database.Tables["BillInfo"].SetDataSource(dtBillInfo);
            this.crystalReportViewer1.ReportSource = cr;


        }

        private void Print_Load(object sender, EventArgs e)
        {

        }
    }
}
