﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRN292
{
    public partial class mainFrm : Form
    {
        public mainFrm()
        {
            InitializeComponent();
        }

        private void mnuMilkTea_Click(object sender, EventArgs e)
        {
            milkteaFrm frm = new milkteaFrm();
            frm.Show();
        }

        private void mnuCategory_Click(object sender, EventArgs e)
        {
            categoryFrm frm = new categoryFrm();
            frm.Show();
        }

        private void mainFrm_Load(object sender, EventArgs e)
        {

        }

        private void mnuBill_Click(object sender, EventArgs e)
        {
            billFrm billFrm = new billFrm();
            billFrm.Show();
        }

        private void ReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reportFrm ReportFrm = new reportFrm();
            ReportFrm.ShowDialog();
        }


        private void mnuInformation_Click(object sender, EventArgs e)
        {
            InfrormatonFrm infoFrm = new InfrormatonFrm();
            infoFrm.ShowDialog();

        }
        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            loginFrm loginFrm = new loginFrm();
            loginFrm.ShowDialog();
        }

    }
}
