﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN292.DB
{
    public class DBConnection
    {
        public static SqlConnection GetConnection()
        {
            //string conStr = @"Data Source=DESKTOP-1Q0I8B0\HOANGTG;Initial Catalog=MilkTea;Persist Security Info=True;User ID=sa;Password=026042855";
            string conStr = @"Data Source=SE140482\LUONGND;Initial Catalog=MilkTea;Persist Security Info=True;User ID=sa;Password=23112015";
            SqlConnection conn = new SqlConnection(conStr);
            return conn;
        }
    }
}
