﻿
namespace PRN292
{
    partial class mainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.mnuManager = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMilkTea = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCategory = new System.Windows.Forms.ToolStripMenuItem();
            this.mnutoolReceipt = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReceipt = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInformation = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportToolStripMnu = new System.Windows.Forms.ToolStripMenuItem();
            this.BillReport = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 30);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(924, 549);
            this.panel1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::PRN292.Properties.Resources.main3;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(924, 549);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(207)))), ((int)(((byte)(144)))));
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuManager,
            this.mnutoolReceipt,
            this.mnuInformation,
            this.ReportToolStripMnu,
            this.mnuClose});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(924, 30);
            this.menuStrip2.TabIndex = 4;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // mnuManager
            // 
            this.mnuManager.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuMilkTea,
            this.mnuCategory});
            this.mnuManager.Name = "mnuManager";
            this.mnuManager.Size = new System.Drawing.Size(82, 26);
            this.mnuManager.Text = "Manager";
            // 
            // mnuMilkTea
            // 
            this.mnuMilkTea.Name = "mnuMilkTea";
            this.mnuMilkTea.Size = new System.Drawing.Size(224, 26);
            this.mnuMilkTea.Text = "MilkTea";
            this.mnuMilkTea.Click += new System.EventHandler(this.mnuMilkTea_Click);
            // 
            // mnuCategory
            // 
            this.mnuCategory.Name = "mnuCategory";
            this.mnuCategory.Size = new System.Drawing.Size(224, 26);
            this.mnuCategory.Text = "Category";
            this.mnuCategory.Click += new System.EventHandler(this.mnuCategory_Click);
            // 
            // mnutoolReceipt
            // 
            this.mnutoolReceipt.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuReceipt});
            this.mnutoolReceipt.Name = "mnutoolReceipt";
            this.mnutoolReceipt.Size = new System.Drawing.Size(73, 26);
            this.mnutoolReceipt.Text = "Receipt";
            // 
            // mnuReceipt
            // 
            this.mnuReceipt.Name = "mnuReceipt";
            this.mnuReceipt.Size = new System.Drawing.Size(224, 26);
            this.mnuReceipt.Text = "Create Bill";
            this.mnuReceipt.Click += new System.EventHandler(this.mnuBill_Click);
            // 
            // mnuInformation
            // 
            this.mnuInformation.Name = "mnuInformation";
            this.mnuInformation.Size = new System.Drawing.Size(101, 26);
            this.mnuInformation.Text = "Information";
            this.mnuInformation.Click += new System.EventHandler(this.mnuInformation_Click);
            // 
            // ReportToolStripMnu
            // 
            this.ReportToolStripMnu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.BillReport});
            this.ReportToolStripMnu.Name = "ReportToolStripMnu";
            this.ReportToolStripMnu.Size = new System.Drawing.Size(68, 26);
            this.ReportToolStripMnu.Text = "Report";
            // 
            // BillReport
            // 
            this.BillReport.Name = "BillReport";
            this.BillReport.Size = new System.Drawing.Size(224, 26);
            this.BillReport.Text = "Bill";
            this.BillReport.Click += new System.EventHandler(this.ReportToolStripMenuItem_Click);
            // 
            // mnuClose
            // 
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(59, 26);
            this.mnuClose.Text = "Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mainFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 579);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip2);
            this.Name = "mainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Milk Tea Management System";
            this.Load += new System.EventHandler(this.mainFrm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem mnuManager;
        private System.Windows.Forms.ToolStripMenuItem mnuMilkTea;
        private System.Windows.Forms.ToolStripMenuItem mnuCategory;
        private System.Windows.Forms.ToolStripMenuItem mnutoolReceipt;
        private System.Windows.Forms.ToolStripMenuItem mnuReceipt;
        private System.Windows.Forms.ToolStripMenuItem mnuInformation;
        private System.Windows.Forms.ToolStripMenuItem ReportToolStripMnu;
        private System.Windows.Forms.ToolStripMenuItem BillReport;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
    }
}